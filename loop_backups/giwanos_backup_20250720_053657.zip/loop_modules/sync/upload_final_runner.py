import os
import sys

# 루트 경로 등록
ROOT_DIR = "C:/giwanos"
if ROOT_DIR not in sys.path:
    sys.path.append(ROOT_DIR)

from send_slack_report import send_slack_message
from upload_notion_safe import upload_to_notion

print("📤 전송기 시작")

# Slack 메시지 전송
send_slack_message("✅ GIWANOS Slack 전송 테스트 완료")

# 회고 리포트 업로드 (루트 기준 경로로 수정)
reflection_path = os.path.join(ROOT_DIR, "reflections", "loop_reflection_log.md")

if os.path.exists(reflection_path):
    print(f"📄 회고 파일 발견: {reflection_path}")
    upload_to_notion(reflection_path, page_title="GIWANOS 회고 리포트")
else:
    print(f"❌ 회고 파일 없음: {reflection_path}")

print("✅ 전송기 완료")
