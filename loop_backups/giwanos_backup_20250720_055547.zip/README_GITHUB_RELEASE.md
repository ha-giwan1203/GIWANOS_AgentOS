# GIWANOS GitHub Release Guide

자동 릴리즈용 실행기, 배치파일 포함.
