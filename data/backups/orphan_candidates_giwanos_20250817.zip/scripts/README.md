﻿## C:\giwanos\scripts




