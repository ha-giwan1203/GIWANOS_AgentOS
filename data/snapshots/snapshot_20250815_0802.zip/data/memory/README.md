﻿## C:\giwanos\data\memory




