﻿## C:\giwanos\data\memory
