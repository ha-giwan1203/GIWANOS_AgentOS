﻿## C:\giwanos\configs
